#pragma once

namespace g_Settings
{
	// Menu
	extern bool bMenu;
	extern bool bShutDown;s
	extern void* hModule;

	// Aimbot
	extern bool bAimbot;
	extern int  iAimbot;
	extern int  iFov;
	extern int  iBone;

	// Entity
	extern bool  bChams;
	extern bool  bRecoil;
	extern bool  bSpread;
	extern float  fSpeed;
	extern float  fWepFov;
	extern float  fCharFov;
}